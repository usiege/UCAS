iris
Source: UCI / Iris Plant
# of classes: 3
# of data: 150
# of features: 4
Files: 
iris.scale
